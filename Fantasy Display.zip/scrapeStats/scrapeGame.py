from bs4 import BeautifulSoup
from urllib import urlopen
import MySQLdb

# class object blueprint
class Matchup:
  def __init__(self, matchupKey, teamID, teamName, passYards, rushYards, totalYards):
    self.matchupKey = matchupKey
    self.teamID = teamID
    self.teamName = teamName
    self.rushYards = rushYards
    self.passYards = passYards
    self.totalYards = totalYards

# The url we will be scraping
boxscore = "https://www.footballdb.com/games/boxscore.html?gid=2018102104"

# get the html
html = urlopen(boxscore)

# create the BeautifulSoup object
soup = BeautifulSoup(html, "lxml")

# function to grab stat from table by rowHeader
def getTeamStat(statName,teamField):
    if teamField=='home':
        teamIndex = 2
    else: 
        teamIndex = 1
    teamStat = soup.find(id='divBox_team').find('td',string=statName).parent.findAll('td')[teamIndex].getText()
    return teamStat
def getTableStat(tableHeader, statHeader, teamField):
    if teamField=='home':
        teamFieldID='boxdiv_home'
    elif teamField=='away':
        teamFieldID='boxdiv_visitor'
    stat = 0
    tableIndex = soup.find(id='divBox_stats').findAll(class_='divider').index(soup.find(id='divBox_stats').find(class_='divider', string=tableHeader))
    # find stat index
    statTable = soup.find(id='divBox_stats').findAll(class_=teamFieldID)[tableIndex]
    statIndex = statTable.find('thead').findAll('th').index(statTable.find('thead').find('th',string=statHeader))
    tableRows = statTable.find('tbody').findAll('tr')
    for tableRow in tableRows:
        stat = stat + int(tableRow.findAll('td')[statIndex].getText())
    return stat
def getTeamStats(teamField):
    if teamField=='home': 

        # get hometeam name
        teamNames = soup.find(id='leftcol').findAll('h1')[0].getText()
        teamName = teamNames[-int(len(teamNames)-teamNames.rfind(" at ")-4):]
        print(teamName)

        # team key - lookup from database

        # total yards allowed
        homeTotalYardsAllowed = getTeamStat('Total Net Yards','away')
        print("Yards Allowed: " + str(homeTotalYardsAllowed))

        # total points allowed
        scoreCell = len(soup.findAll(class_='statistics')[0].findAll('tr')[1].findAll('td'))-1 # find the location of the score in case OT
        homePointsAllowed = soup.findAll(class_='statistics')[0].findAll('tr')[1].findAll('td')[scoreCell].getText()
        print("Points Allowed: " + str(homePointsAllowed))

        # sacks - Times Sacked
        homeSacks = getTeamStat('Sacked - Yds Lost','away')
        homeSacks = homeSacks[:homeSacks.find("-")] # remove the yds lost substring
        print("Sacks: " + str(homeSacks))

        # blocked Punts - Had Blocked	
        homeBlockedPunts = getTeamStat('Had Blocked','away')
        print("Punts Blocked: " + str(homeBlockedPunts))

        # count of FGs blocked
        blockedFGs = 0
        kickerRows = soup.findAll('th', string='PAT')[0].parent.parent.parent.findAll(class_='row0 right') # change [0] to [1] for away
        for kicker in kickerRows:
            blockedFGs = blockedFGs + kicker.findAll('td')[9].getText().count("B")
        print("FGs Blocked: " + str(blockedFGs))

        # ints
        homeInts = getTeamStat('Interception Returns','home')
        homeInts = homeInts[:homeInts.find("-")] # remove the yds lost substring
        print("Interceptions: " + str(homeInts))

        # fumbles - Given up Fumbles
        homeForcedFumbles = getTeamStat('Fumbles - Lost','away')
        homeForcedFumbles = homeForcedFumbles[:homeForcedFumbles.find("-")] # remove the yds lost substring
        print("Forced Fumbles: " + str(homeForcedFumbles))

        # fumbles recovered - Given up fumbles turned over
        homeRecoveredFumbles = getTeamStat('Fumbles - Lost','away')
        homeRecoveredFumbles = homeRecoveredFumbles[-homeRecoveredFumbles.rfind("-"):] # remove the yds lost substring
        print("Recovered Fumbles: " + str(homeRecoveredFumbles))

        # kick return TDs
        homeKickoffReturnTDs = getTableStat('Kickoff Returns','TD','home')
        print("Kickoff TDs: " + str(homeKickoffReturnTDs))

        # punt TDs
        homePuntReturnTDs = getTableStat('Punt Returns','TD','home')
        print("Punt TDs: " + str(homePuntReturnTDs))

        # def TDs
        homeDefensiveTDs = getTableStat('Defense','TD','home')
        print("Defensive TDs: " + str(homeDefensiveTDs))
    elif teamField=='away':
        # get hometeam name
        teamNames = soup.find(id='leftcol').findAll('h1')[0].getText()
        teamName = teamNames[:teamNames.find(" at ")]
        print(teamName)

        # team key - lookup from database

        # total yards allowed
        homeTotalYardsAllowed = getTeamStat('Total Net Yards','home')
        print("Yards Allowed: " + str(homeTotalYardsAllowed))

        # total points allowed
        scoreCell = len(soup.findAll(class_='statistics')[0].findAll('tr')[2].findAll('td'))-1 # find the location of the score in case OT
        homePointsAllowed = soup.findAll(class_='statistics')[0].findAll('tr')[2].findAll('td')[scoreCell].getText()
        print("Points Allowed: " + str(homePointsAllowed))

        # sacks - Times Sacked
        homeSacks = getTeamStat('Sacked - Yds Lost','home')
        homeSacks = homeSacks[:homeSacks.find("-")] # remove the yds lost substring
        print("Sacks: " + str(homeSacks))

        # blocked Punts - Had Blocked	
        homeBlockedPunts = getTeamStat('Had Blocked','home')
        print("Punts Blocked: " + str(homeBlockedPunts))

        # count of FGs blocked
        blockedFGs = 0
        kickerRows = soup.findAll('th', string='PAT')[1].parent.parent.parent.findAll(class_='row0 right') # change [0] to [1] for away
        for kicker in kickerRows:
            blockedFGs = blockedFGs + kicker.findAll('td')[9].getText().count("B")
        print("FGs Blocked: " + str(blockedFGs))

        # ints
        homeInts = getTeamStat('Interception Returns','away')
        homeInts = homeInts[:homeInts.find("-")] # remove the yds lost substring
        print("Interceptions: " + str(homeInts))

        # fumbles - Given up Fumbles
        homeForcedFumbles = getTeamStat('Fumbles - Lost','home')
        homeForcedFumbles = homeForcedFumbles[:homeForcedFumbles.find("-")] # remove the yds lost substring
        print("Forced Fumbles: " + str(homeForcedFumbles))

        # fumbles recovered - Given up fumbles turned over
        homeRecoveredFumbles = getTeamStat('Fumbles - Lost','home')
        homeRecoveredFumbles = homeRecoveredFumbles[-homeRecoveredFumbles.rfind("-"):] # remove the yds lost substring
        print("Recovered Fumbles: " + str(homeRecoveredFumbles))

        # kick return TDs
        homeKickoffReturnTDs = getTableStat('Kickoff Returns','TD','away')
        print("Kickoff TDs: " + str(homeKickoffReturnTDs))

        # punt TDs
        homePuntReturnTDs = getTableStat('Punt Returns','TD','away')
        print("Punt TDs: " + str(homePuntReturnTDs))

        # def TDs
        homeDefensiveTDs = getTableStat('Defense','TD','away')
        print("Defensive TDs: " + str(homeDefensiveTDs))

getTeamStats('home')
print("-------------")
getTeamStats('away')


