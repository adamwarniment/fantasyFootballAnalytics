from bs4 import BeautifulSoup
from urllib import urlopen
import MySQLdb

# database connection
mydb = MySQLdb.connect(
  host='35.231.120.222', 
  user='root', 
  passwd='may132017',
  database='nflStats'
)

# functions
def getIntStatArray(statName):
    statArray = []
    for cell in soup.find(id="gamelog_opp2018").findAll('td', attrs={"data-stat": statName}):
        if not cell.getText(): statArray.append(int("0"))
        else: statArray.append(int(cell.getText()))
    return statArray

# class object blueprint
class Matchup:
  def __init__(self, matchupKey, teamID, teamName, passYards, rushYards, totalYards):
    self.matchupKey = matchupKey
    self.teamID = teamID
    self.teamName = teamName
    self.rushYards = rushYards
    self.passYards = passYards
    self.totalYards = totalYards

# The url we will be scraping
brownsGameLog = "https://www.pro-football-reference.com/teams/cle/2018/gamelog/index.htm"

# get the html
html = urlopen(brownsGameLog)

# create the BeautifulSoup object
soup = BeautifulSoup(html, "lxml")

# scrub weeks as primary key
weekNums = [int(td.getText()) for td in soup.find(id="gamelog_opp2018").findAll('tbody')[0].findAll('th', attrs={"data-stat": "week_num"})]

# scrub for team names
oppsNames = [td.getText() for td in soup.find(id="gamelog_opp2018").findAll('td', attrs={"data-stat": "opp"})]

# scrub for results to determine if game is complete
gameResults = [td.getText() for td in soup.find(id="gamelog_opp2018").findAll('td', attrs={"data-stat": "game_outcome"})]

# lookup teamIDs
oppsIDs = []
for opp in oppsNames:
  mycursor = mydb.cursor()
  mycursor.execute("SELECT teamKey FROM teamKeys WHERE TeamName='" + opp + "'")
  foundKey = mycursor.fetchone()[0]
  oppsIDs.append(foundKey)

# scrub for team stats
oppsPassYards = getIntStatArray("pass_yds")
oppsRushYards = getIntStatArray("rush_yds")
oppsTotalYards = [x + y for x, y in zip(oppsPassYards, oppsRushYards)]

# create all objects
matchups = [Matchup(matchupKey, teamID, teamName, rushYards, passYards, totalYards) for matchupKey, teamID, teamName, rushYards, passYards, totalYards in zip(weekNums, oppsIDs, oppsNames, oppsRushYards, oppsPassYards, oppsTotalYards)]
for matchup in matchups:
  if matchup.totalYards != 0:
    #print("In week " + matchup.matchupKey + ", the " + matchup.teamName + "(" + matchup.teamID + ")" + " passed for " + str(matchup.passYards) + "yds and rushed for " + str(matchup.rushYards) + "yds totaling " + str(matchup.totalYards) + "yds.")

    # get TeamID from DB
    sql = "INSERT IGNORE INTO cle VALUES (%s, %s, %s, %s, %s, %s)"
    val = (matchup.matchupKey, matchup.teamID, matchup.teamName, matchup.rushYards, matchup.passYards, matchup.totalYards)
    mycursor.execute(sql, val)

    mydb.commit()

#print(mycursor.rowcount, "record inserted.")
    

#mycursor = mydb.cursor()
#mycursor.execute("SELECT * FROM dstStats")
#myresult = mycursor.fetchall()
#for x in myresult:
#  print(x)
