from bs4 import BeautifulSoup
from urllib import urlopen
import MySQLdb

# database connection
mydb = MySQLdb.connect(
  host='35.231.120.222', 
  user='root', 
  passwd='may132017',
  database='nflStats'
)

# get avg yards
mycursor = mydb.cursor()
mycursor.execute("SELECT sum(totalYards) FROM cle")
seasonTotalYards = mycursor.fetchone()[0]
print(seasonTotalYards)