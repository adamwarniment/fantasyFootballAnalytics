function graphProj() {
    var weekString = '';
    var weekGraphSelect = document.getElementById("weekGraphSelect");
    weekString = weekGraphSelect.options[weekGraphSelect.selectedIndex].value;

    var posString = '';
    var posGraphSelect = document.getElementById("posGraphSelect");
    posString = posGraphSelect.options[posGraphSelect.selectedIndex].value;

    if (weekGraphSelect.length == 0) { 
        document.getElementById("weekGraphDisplay").innerHTML = "Select a WEEK.";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var projections = JSON.parse(xmlhttp.responseText);
                graphNumbers(projections[0],projections[1]);// this.responseText;
            }
        };
        xmlhttp.open("GET", "projections.php?week=" + weekString + "&pos=" + posString, true);
        xmlhttp.send();
    }

}

function graphNumbers(labelArray,dataArray) {
    var MONTHS = labelArray;
    var color = Chart.helpers.color;
    var barChartData = {
        labels: labelArray,
        datasets: [{
            label: 'Dataset 1',
            backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
            borderColor: window.chartColors.red,
            borderWidth: 1,
            data: dataArray
        }]

    };

    var ctx = document.getElementById('canvas').getContext('2d');
    window.myBar = new Chart(ctx, {
        type: 'horizontalBar',
        data: barChartData,
        options: {
            responsive: true,
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Chart.js Bar Chart'
            }
        }
    });
}
