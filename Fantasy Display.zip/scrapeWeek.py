from bs4 import BeautifulSoup
from urllib import urlopen
import math
import MySQLdb

teamNameLookup = ['New York Jets', 'Minnesota Vikings', 'Baltimore Ravens', 'Los Angeles Rams', 'Cleveland Browns', 'Jacksonville Jaguars', 'Miami Dolphins', 'Washington Redskins', 'Carolina Panthers', 'Chicago Bears', 'Cincinnati Bengals', 'Denver Broncos', 'Philadelphia Eagles', 'Detroit Lions', 'Pittsburgh Steelers', 'Tennessee Titans', 'Kansas City Chiefs', 'New England Patriots', 'Tampa Bay Buccaneers', 'Atlanta Falcons', 'Dallas Cowboys', 'Houston Texans', 'Seattle Seahawks', 'Green Bay Packers', 'New York Giants', 'Arizona Cardinals', 'Indianapolis Colts', 'San Francisco 49ers', 'Buffalo Bills', 'Los Angeles Chargers', 'Oakland Raiders', 'New Orleans Saints']
teamIDLookup = ['NYJ', 'MIN', 'BAL', 'LA', 'CLE', 'JAX', 'MIA', 'WAS', 'CAR', 'CHI', 'CIN', 'DEN', 'PHI', 'DET', 'PIT', 'TEN', 'KC', 'NE', 'TB', 'ATL', 'DAL', 'HOU', 'SEA', 'GB', 'NYG', 'ARI', 'IND', 'SF', 'BUF', 'LAC', 'OAK', 'NO']

# one function to sign into mysql
def connectToMySQL():
    mydb = MySQLdb.connect(
        host='localhost', #host='35.231.120.222', 
        user='root', 
        passwd='may132017',
        db='fantasyAnalytics'
    )
    return mydb


# return teamID function without DB
def getTeamID(teamName):
    teamIndex = teamNameLookup.index(teamName)
    return teamIDLookup[teamIndex]

# return teamName function without DB
def getTeamName(teamID):
    teamIndex = teamIDLookup.index(teamID)
    return teamNameLookup[teamIndex]

def storeAllStatsDST(week):
    # database connection
    mydb = connectToMySQL()
    
    # The url we will be scraping
    boxscore = "https://www.footballdb.com/fantasy-football/index.html?pos=DST&yr=2018&wk=" + str(week) +"&rules=1"

    # get the html
    html = urlopen(boxscore)

    # create the BeautifulSoup object
    soup = BeautifulSoup(html, "html.parser")

    # collect team rows
    teamRow = None
    teamRows = soup.find(class_='statistics scrollable').find('tbody').findAll('tr')

    # byeCheckArray
    byeCheckArray = []

    for team in teamRows:
        # team name
        teamName = str(team.findAll('td')[0].find('a').getText())
        # opp name
        matchupString = team.findAll('td')[1].getText()
        oppName = str(getTeamName(matchupString[-int(len(matchupString)-matchupString.rfind(" ")-1):]))
        # team week ID
        teamID = getTeamID(teamName) + str(week)
        byeCheckArray.append(getTeamID(teamName))
        # matchup team week ID
        matchupID = matchupString[-int(len(matchupString)-matchupString.rfind(" ")-1):] + str(week)
        #bye week
        bye=False
        # home team
        location = team.findAll('td')[1].getText()
        if location.find('@') != -1:
            home = True
        else:
            home = False
        # sack
        sacks = team.findAll('td')[3].getText()
        # int
        inters = team.findAll('td')[4].getText()
        # saf
        safties = team.findAll('td')[5].getText()
        # FR
        fumRecs = team.findAll('td')[6].getText()
        # Blk
        blocks = team.findAll('td')[7].getText()
        # TD
        tds = team.findAll('td')[8].getText()
        # PA
        ptsAllowed = team.findAll('td')[9].getText()
        # PassYds
        passYdsAllowed = team.findAll('td')[10].getText()
        # RushYds
        rushYdsAllowed = team.findAll('td')[11].getText()
        # TotYds
        totYdsAllowed = team.findAll('td')[12].getText()

        # get TeamID from DB ####### ADD MORE IN THE ON DUP %s %s %s for all values to overwrite
        sql = "INSERT INTO dstStats VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE matchupID=%s, opp=%s, byeWeek=%s, home=%s, sack=%s, inter=%s, safety=%s, fumRec=%s, block=%s, touchdown=%s, ptsAllowed=%s, passYdsAllowed=%s, rushYdsAllowed=%s, totalYdsAllowed=%s"
        val = (teamID, matchupID, teamName, oppName, bye, home, sacks, inters, safties, fumRecs, blocks, tds, ptsAllowed, passYdsAllowed, rushYdsAllowed, totYdsAllowed, matchupID, oppName, bye, home, sacks, inters, safties, fumRecs, blocks, tds, ptsAllowed, passYdsAllowed, rushYdsAllowed, totYdsAllowed)
        mycursor = mydb.cursor()
        mycursor.execute(sql, val)
        mydb.commit()
        
    # check if team was not found and therefor on bye
    for teamID in teamIDLookup:
        try:
            index = byeCheckArray.index(teamID)
        except:
            index = -1
        if index == -1:
             # team must be on bye
            gameID = teamID + str(week)
            print("BYE WEEK: " + teamID)
            teamName = getTeamName(teamID)
            sql = "INSERT INTO dstStats(gameID,matchupID,team,byeWeek) VALUES (%s, %s, %s, %s) ON DUPLICATE KEY UPDATE matchupID=%s"
            val = (gameID, "BYE", teamName, True, "BYE")
            mycursor = mydb.cursor()
            mycursor.execute(sql, val)
            mydb.commit()


# get stat from DB
def getAvgStat(teamName, statName):
    mydb = connectToMySQL()

    sql = "SELECT AVG(" + statName + ") FROM dstStats WHERE team = '" + teamName + "' AND "+statName+" IS NOT NULL"
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    return float(mycursor.fetchone()[0])

# get stat from DB
def getAvgStatAllowed(teamName, statName):
    mydb = connectToMySQL()

    sql = "SELECT AVG(" + statName + ") FROM dstStats WHERE opp = '" + teamName + "' AND "+statName+" IS NOT NULL"
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    return float(mycursor.fetchone()[0])

def getStatFromGameID(gameID, statName):
    mydb = connectToMySQL()

    sql = "SELECT " + statName + " FROM dstStats WHERE gameID = '" + gameID + "' AND "+statName+" IS NOT NULL"
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    return int(mycursor.fetchone()[0])

def getStatAllowedFromGameID(gameID, statName):
    mydb = connectToMySQL()

    sql = "SELECT " + statName + " FROM dstStats WHERE matchupID = '" + gameID + "'"
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    return int(mycursor.fetchone()[0])


def getStatPrediction(teamName,oppName,statName):
    # find opponent

    mydb = connectToMySQL()

    sql = "SELECT opp,team,matchupID,gameID,byeWeek FROM dstStats WHERE opp = '" + oppName +"'"
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    oppsArray = mycursor.fetchall()
    # calc opp diff avg - How many more/less of the stats does their opponent allow?
    oppStatDiffTotal = 0
    oppGameCount = 0
    for opp in oppsArray:
        if opp[4] != True:
            recordDiff = getAvgStat(opp[1],statName)-getStatFromGameID(opp[3],statName)
            # if allowed stat projection, take the opposite
            if "Allowed" in statName:
                modifier = -1
            else:
                modifier = 1
            oppStatDiffTotal = oppStatDiffTotal + (recordDiff * modifier)
            oppGameCount = oppGameCount + 1
    a = oppStatDiffTotal/oppGameCount # opp allows this many more/less stats than opps take on avg

    # calc team diff avg - How many more/less of the stat does the team take?
    sql = "SELECT opp,gameID,byeWeek,matchupID FROM dstStats WHERE team = '" + teamName + "'"
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    teamArray = mycursor.fetchall()
    # get avg stats allowed for each team
    teamStatDiffTotal = 0
    teamGameCount = 0
    for teamOpp in teamArray:
        if teamOpp[2] != True:
            recordDiff = getStatAllowedFromGameID(teamOpp[3],statName) - getAvgStatAllowed(teamOpp[0],statName)
            # if allowed stat projection, take the opposite
            if "Allowed" in statName:
                modifier = -1
            else:
                modifier = 1
            teamStatDiffTotal = teamStatDiffTotal + (recordDiff * modifier)
            teamGameCount = teamGameCount + 1
    b = teamStatDiffTotal/teamGameCount # team takes this many more/less stat on avg

    teamStatAvg = getAvgStat(teamName,statName)
    oppStatAllowedAvg = getAvgStatAllowed(oppName,statName)
    if "Allowed" in statName:
        prediction = (teamStatAvg + a)*0.7 + (oppStatAllowedAvg + b)*0.3
    else:
        prediction = (teamStatAvg + a)*0.3 + (oppStatAllowedAvg + b)*0.7
    
    #teamStatPredictionA = (oppStatAllowedAvg + teamStatAvg)/2 + a + b
    #teamStatPredictionB = (oppStatAllowedAvg + b)*.3 + (teamStatAvg + a)*.7
    #finalPrediction = (teamStatPredictionA*0.7+teamStatPredictionB*0.3)
    #print(teamStatAvg,a,oppStatAllowedAvg,b,round(prediction,0))
    return(prediction)

#getStatPrediction('Tampa Bay Buccaneers','Cleveland Browns','ptsAllowed')

def getProjections(teamName,week):
    teamID = getTeamID(teamName)
    
    mydb = connectToMySQL()

    sql = "SELECT week" + str(week) + " FROM schedule WHERE teamID = '" + teamID + "'"
    mycursor = mydb.cursor()
    mycursor.execute(sql)

    oppID = str(mycursor.fetchone()[0])
    if oppID != 'BYE':
        oppName = getTeamName(oppID)

        projections = [getStatPrediction(teamName,oppName,'sack'),
            getStatPrediction(teamName,oppName,'inter'),
            getStatPrediction(teamName,oppName,'fumRec'),
            getStatPrediction(teamName,oppName,'safety'),
            getStatPrediction(teamName,oppName,'block'),
            getStatPrediction(teamName,oppName,'touchdown'),
            getStatPrediction(teamName,oppName,'ptsAllowed'),
            getStatPrediction(teamName,oppName,'passYdsAllowed') + getStatPrediction(teamName,oppName,'rushYdsAllowed')
        ]

        i=0
        while (i<len(projections)):
            if projections[i] < 0:
                projections[i] = 0
            i += 1

        floor = getFantasyPoints(math.floor(projections[0]),
            math.floor((projections[1]+projections[2]))/2,
            math.floor((projections[1]+projections[2]))/2,
            round((projections[3]+projections[4]),0)/2,
            round((projections[3]+projections[4]),0)/2,
            round(projections[5],0),
            math.ceil(projections[6]+3),
            math.ceil(projections[7]+25)
        )
        ceiling = getFantasyPoints(math.ceil(projections[0]),
            math.ceil((projections[1]+projections[2]))/2,
            math.ceil((projections[1]+projections[2]))/2,
            round((projections[3]+projections[4])/2,0),
            round((projections[3]+projections[4])/2,0),
            round(projections[5],0),
            math.floor(projections[6]),
            math.floor(projections[7])
        )

        precise = getFantasyPoints(projections[0],projections[1],projections[2],0,0,0,projections[6],projections[7])
        precise = round(precise,2)

        median = (floor+ceiling)/2
        outlier = ceiling + 6

        print(teamName," vs. ",oppName)
        print("Sacks: ",projections[0])
        print("TOs: ",projections[1]+projections[2])
        print("Sfts & Blks: ",projections[3]+projections[4])
        print("TDs: ",projections[5])
        print("Pts Allow: ",projections[6])
        print("Yards Allowed: ",projections[7])
        print("Projection Dist:",floor,precise,ceiling,outlier)

        sql = "INSERT INTO dstProjections (teamID, team, week" + str(week) + ") VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE week" + str(week) +"=%s"
        val =  (teamID, getTeamName(teamID), precise, precise)
        mycursor = mydb.cursor()
        mycursor.execute(sql, val)
        mydb.commit()
    else: 
        sql = "INSERT IGNORE INTO dstProjections (teamID, team) VALUES (%s, %s)"
        val =  (teamID, getTeamName(teamID))
        mycursor = mydb.cursor()
        mycursor.execute(sql, val)
        mydb.commit()

def getFantasyPoints(sacks, inters, fumRecs, safties, blocks, tds, ptsAllowed, totYards):
    stats = [sacks, inters, fumRecs, safties, blocks, tds, ptsAllowed, totYards]
    # calc tier for ptsAllowed
    pointsPA = 0
    if stats[6] == 0: pointsPA = 5
    elif 1 <= stats[6] <= 6: pointsPA = 4
    elif 7 <= stats[6] <= 13: pointsPA = 3
    elif 14 <= stats[6] <= 17: pointsPA = 1
    elif 18 <= stats[6] <= 27: pointsPA = 0
    elif 28 <= stats[6] <= 34: pointsPA = -1
    elif 35 <= stats[6] <= 45: pointsPA = -3
    elif 46 <= stats[6]: pointsPA = -5
    # calc tier for ydsAllowed
    pointsYA = 0
    if stats[7] < 100: pointsYA = 5
    elif 100 <= stats[7] <= 199: pointsYA = 3
    elif 200 <= stats[7] <= 299: pointsYA = 2
    elif 300 <= stats[7] <= 399: pointsYA = -1
    elif 400 <= stats[7] <= 449: pointsYA = -3
    elif 450 <= stats[7] <= 499: pointsYA = -5
    elif 500 <= stats[7] <= 549: pointsYA = -6
    elif 550 <= stats[7]: pointsYA = -7

    # calculate the points
    fantasyPoints = stats[0]*1 + stats[1]*2 + stats[2]*2 + stats[3]*2 + stats[4]*2 + stats[5]*6 + pointsPA + pointsYA
    return fantasyPoints

def scrapeSchedule():
    mydb = connectToMySQL()

    #http://www.espn.com/nfl/schedulegrid
    # The url we will be scraping
    boxscore = "http://www.espn.com/nfl/schedulegrid"

    # get the html
    html = urlopen(boxscore)

    # create the BeautifulSoup object
    soup = BeautifulSoup(html, "lxml")

    teamRows = soup.find(class_='tablehead').findAll('tr')

    for team in teamRows:
        schedule = []
        if team.findAll('td')[0].getText() != 'NFL Schedule Grid' and team.findAll('td')[0].getText() != 'TEAM':
            teamID = team.findAll('td')[0].getText()
            if teamID == 'LAR':
                teamID = 'LA'
            elif teamID == 'WSH':
                teamID = 'WAS'
            i=1
            while i<18:
                schedule.append(str(team.findAll('td')[i].getText().replace(' ','').replace('@','')))
                i += 1
            
            #print(str(teamID),getTeamName(teamID),schedule[0],schedule[1])
            # get TeamID from DB ####### ADD MORE IN THE ON DUP %s %s %s for all values to overwrite
            sql = "INSERT IGNORE INTO schedule VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            val =  (teamID, getTeamName(teamID),schedule[0],schedule[1],schedule[2],schedule[3],schedule[4],schedule[5],schedule[6],schedule[7],schedule[8],schedule[9],schedule[10],schedule[11],schedule[12],schedule[13],schedule[14],schedule[15],schedule[16])
            mycursor = mydb.cursor()
            mycursor.execute(sql, val)
            mydb.commit()


def storeFantasyScoresDST():
    mydb = connectToMySQL()

    # get all rows in dstStats
    sql = "SELECT * FROM dstStats WHERE NOT matchupID='BYE'"
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    allGames = mycursor.fetchall()

    for game in allGames:
        #print(game[0],str(getFantasyPoints(game[6],game[7],game[8],game[9],game[10],game[11],game[12],game[15])))
        # get gameID - EX "CLE1"
        gameID = game[0]
        # extract teamID - all but last char of gameID
        week = gameID[-1:]
        teamID = gameID[:-1]
        # projection
        proj = getFantasyPoints(game[6],game[7],game[8],game[9],game[10],game[11],game[12],game[15])
        print(week,teamID,str(getFantasyPoints(game[6],game[7],game[8],game[9],game[10],game[11],game[12],game[15])))
        sqlStore = "INSERT IGNORE INTO dstActual (teamID, week"+str(week)+") VALUES (%s, %s) ON DUPLICATE KEY UPDATE week" + str(week) +"=%s"
        val = (teamID,proj,proj)
        mycursor = mydb.cursor()
        mycursor.execute(sqlStore, val)
        mydb.commit()
    # extract week - "week" + last char of gameID



#print(getStatAllowedFromGameID('CLE7', 'sack'))

for teamName in teamNameLookup:
    getProjections(teamName,15)

#getStatPrediction('San Francisco 49ers','Oakland Raiders','ptsAllowed')

#storeAllStatsDST(10)

def getRankDiff():
    mydb = connectToMySQL()
    mycursor = mydb.cursor()
    # get teams that played
    sql = "SELECT teamID FROM schedule WHERE NOT week5='BYE'"
    mycursor.execute(sql)
    allTeams = mycursor.fetchall()

    topTenTotal = 0
    midTenTotal = 0

    for team in allTeams:
        teamID = team[0]

        projRank = 0
        actualRank = 0

        sqlProj = "SELECT teamID FROM dstProjections ORDER BY week5 DESC"
        mycursor = mydb.cursor()
        mycursor.execute(sqlProj)
        allProjs = mycursor.fetchall()
        for proj in allProjs:
            if str(proj[0]) == teamID:
                projRank = int(allProjs.index(proj)) + 1

        sqlActual = "SELECT teamID FROM dstActual ORDER BY week5 DESC"
        mycursor = mydb.cursor()
        mycursor.execute(sqlActual)
        allActuals = mycursor.fetchall()
        for actual in allActuals:
            if str(actual[0]) == teamID:
                actualRank = int(allActuals.index(actual)) + 1

        if projRank < 11 and actualRank > 10:
            topTenTotal = topTenTotal + (projRank-actualRank)
        if 10 < projRank <= 20:
            midTenTotal = midTenTotal + (projRank-actualRank)

        print(teamID,projRank,actualRank,projRank-actualRank)

    print(str(topTenTotal/10),(midTenTotal/10))



    #for proj in allProjs:
    #    rank = int(allProjs.index(proj)) + 1
    #    sqlActual = "SELECT week1 FROM dstActual WHERE teamID='" +proj[0]+ "'"
    #    mycursor = mydb.cursor()
    #    mycursor.execute(sqlActual)
    #    actual = mycursor.fetchone()
    #    print(proj,actual,rank)

    
    #sqlLeftJoin = "SELECT dstProjections.teamID, dstProjections.week1, dstActual.week1 FROM dstProjections LEFT JOIN dstActual ON dstProjections.teamID = dstActual.teamID ORDER BY dstActual.week1"
    #mycursor = mydb.cursor()
    #mycursor.execute(sqlLeftJoin)
    #teamDiffs = mycursor.fetchall()
    
    #for team in teamDiffs:
    #    print(team[0],round( float(team[2]) - float(team[1]) , 2))

#getRankDiff()