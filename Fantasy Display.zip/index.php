<html>
 <head>
 <title>Bar Chart</title>
	<script src="Chart.bundle.js"></script>
    <script src="utils.js"></script>
	<style>
	canvas {
		-moz-user-select: none;
		-webkit-user-select: none;
		-ms-user-select: none;
	}
	</style>
 </head>

 <body>
 <select id="weekGraphSelect" onchange="graphProj()">
    <option value="">Select a week...</option>  
    <option value="week1">Week 1</option>
    <option value="week2">Week 2</option>
    <option value="week3">Week 3</option>
    <option value="week4">Week 4</option>
    <option value="week5">Week 5</option>
    <option value="week6">Week 6</option>
    <option value="week7">Week 7</option>
    <option value="week8">Week 8</option>
    <option value="week9">Week 9</option>
    <option value="week10">Week 10</option>
    <option value="week11">Week 11</option>
    <option value="week12">Week 12</option>
    <option value="week13">Week 13</option>
    <option value="week14">Week 14</option>
    <option value="week15">Week 15</option>
    <option value="week16">Week 16</option>
    <option value="week17">Week 17</option>
  </select>

<select id="posGraphSelect" onchange="graphProj()">
    <option value="">Select a position...</option>  
    <option value="qb">QB</option>
    <option value="rb">RB</option>
    <option value="wr">WR</option>
    <option value="te">TE</option>
    <option value="dst">D/ST</option>
  </select>

 <div id="container" style="width: 75%; height: 100%">
		<canvas id="canvas"></canvas>
	</div>
<br>

<div id="weekGraphDisplay">

</div>

<?php
    $servername = "localhost";
    $username = "root";
    $password = "may132017";
    $dbname = "fantasyAnalytics";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    //echo "Connected successfully";

    $sql = "SELECT team, week10 FROM dstProjections ORDER BY week10 DESC";
    $result = $conn->query($sql);

    $rank = 1;
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            // echo "[Rank ". $rank . "] " . $row["team"]. " - Proj: " . $row["week10"]."<br>";
            $rank = $rank + 1;
        }
    } else {
        echo "0 results";
    }

    $conn = null;
?>



 </body>

<script src="/index.js"></script>

</html>