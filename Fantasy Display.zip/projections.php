<?php
    // get the parameters from URL
    $week = $_GET["week"];
    $pos = $_GET["pos"];
    $db = $pos."Projections";

    $servername = "localhost";
    $username = "root";
    $password = "may132017";
    $dbname = "fantasyAnalytics";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    //echo "Connected successfully";

    $sql = "SELECT team, ".$week." FROM ".$db." WHERE ".$week." IS NOT NULL ORDER BY ".$week. " DESC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $results = array();
        $projs = array();
        $teams = array();
        // output data of each row
        while($row = $result->fetch_assoc()) {
            array_push($projs,$row[$week]);
            array_push($teams,(string)$row["team"]);
            //echo "Team: " . $row["team"]. " - Proj: " . $row[$week]."<br>";
        }
        array_push($results,$teams);
        array_push($results,$projs);
        echo json_encode($results);
    } else {
        echo "0 results for " .$week;
    }
?>