from bs4 import BeautifulSoup
from urllib import urlopen
import math
import MySQLdb
import re

teamShortNameLookup = ['Jets', 'Vikings', 'Ravens', 'Rams', 'Browns', 'Jaguars', 'Dolphins', 'Redskins', 'Panthers', 'Bears', 'Bengals', 'Broncos', 'Eagles', 'Lions', 'Steelers', 'Titans', 'Chiefs', 'Patriots', 'Buccaneers', 'Falcons', 'Cowboys', 'Texans', 'Seahawks', 'Packers', 'Giants', 'Cardinals', 'Colts', '49ers', 'Bills', 'Chargers', 'Raiders', 'Saints']
teamNameLookup = ['New York Jets', 'Minnesota Vikings', 'Baltimore Ravens', 'Los Angeles Rams', 'Cleveland Browns', 'Jacksonville Jaguars', 'Miami Dolphins', 'Washington Redskins', 'Carolina Panthers', 'Chicago Bears', 'Cincinnati Bengals', 'Denver Broncos', 'Philadelphia Eagles', 'Detroit Lions', 'Pittsburgh Steelers', 'Tennessee Titans', 'Kansas City Chiefs', 'New England Patriots', 'Tampa Bay Buccaneers', 'Atlanta Falcons', 'Dallas Cowboys', 'Houston Texans', 'Seattle Seahawks', 'Green Bay Packers', 'New York Giants', 'Arizona Cardinals', 'Indianapolis Colts', 'San Francisco 49ers', 'Buffalo Bills', 'Los Angeles Chargers', 'Oakland Raiders', 'New Orleans Saints']
teamIDLookup = ['NYJ', 'MIN', 'BAL', 'LA', 'CLE', 'JAX', 'MIA', 'WAS', 'CAR', 'CHI', 'CIN', 'DEN', 'PHI', 'DET', 'PIT', 'TEN', 'KC', 'NE', 'TB', 'ATL', 'DAL', 'HOU', 'SEA', 'GB', 'NYG', 'ARI', 'IND', 'SF', 'BUF', 'LAC', 'OAK', 'NO']

# one function to sign into mysql
def connectToMySQL():
    mydb = MySQLdb.connect(
        host='localhost', #host='35.231.120.222', 
        user='root', 
        passwd='may132017',
        db='fantasyAnalytics'
    )
    return mydb

# return teamID function without DB
def getTeamID(teamName,short):
    if short == True:
        teamIndex = teamShortNameLookup.index(teamName)
    else:
        teamIndex = teamNameLookup.index(teamName)
    
    return teamIDLookup[teamIndex]

# return teamName function without DB
def getTeamName(teamID):
    teamIndex = teamIDLookup.index(teamID)
    return teamNameLookup[teamIndex]

def scrapeQBStats(week):
    # quarteback = qb; qb_rush_car, qb_rush_yds, qb_rush_tds, qb_pass_att, qb_pass_comp, qb_pass_yds, qb_pass_tds,
    # running back = rb; rb_rush_car, rb_rush_yds, rb_rush_tds, rb_rec_tar, rb_rec_comp rb_rec_yds, rb_rec_tds
    # wide reciever = wr; wr_rec_tar, wr_rec_comp, wr_rec_yds, wr_rec_tds
    # tight end = te; te_rec_tar, te_rec_comp, te_rec_wds, te_rec_tds
    
    # database connection
    mydb = connectToMySQL()

    # The url we will be scraping
    teamStats = "https://www.cbssports.com/fantasy/football/stats/posvsdef/QB/all/" + str(week) + "/standard" 
    # get the html
    html = urlopen(teamStats)
    # create the BeautifulSoup object
    soup = BeautifulSoup(html, "lxml")

    # collect team rows
    teamRows = soup.findAll(class_='data compact')[0].findAll('tr', {"class" : re.compile('row*')})

    week = str("%02d" % (week,))

    for team in teamRows:
        # check if total team stat row
        if not team.has_attr('id'):
            # team name 
            name = team.findAll('td')[1].getText()
            name = str(name.split()[0])
            teamID = getTeamID(name,True) + week
            teamName = getTeamName(str(getTeamID(name,True)))
            # opp name
            opp = team.findAll('td')[1].getText()
            opp = str(opp.split()[3])
            oppID = getTeamID(opp,True) + week
            oppName = getTeamName(str(getTeamID(opp,True)))
            # att 2
            qb_pass_att = float(team.findAll('td')[2].getText())
            # comp 3
            qb_pass_comp = float(team.findAll('td')[3].getText())
            # yd 4
            qb_pass_yds = float(team.findAll('td')[4].getText())
            # td 5
            qb_pass_tds = float(team.findAll('td')[5].getText())
            #####
            # rush_car 7
            qb_rush_car = float(team.findAll('td')[8].getText())
            # rush_yds 8
            qb_rush_yds = float(team.findAll('td')[9].getText())
            #####
            # rush_tds 11
            qb_rush_tds = float(team.findAll('td')[11].getText())
            # qb_YPA
            if qb_pass_att == 0:
                qb_YPA = 0
            else:
                qb_YPA = round(qb_pass_yds/qb_pass_att,2)

            sql = "INSERT INTO teamStats(teamID, oppID, week, teamName, oppName, qb_pass_att, qb_pass_comp, qb_pass_yds, qb_pass_tds, qb_rush_car, qb_rush_yds, qb_rush_tds, qb_YPA) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE teamID=%s, oppID=%s, week=%s, teamName=%s, oppName=%s, qb_pass_att=%s, qb_pass_comp=%s, qb_pass_yds=%s, qb_pass_tds=%s, qb_rush_car=%s, qb_rush_yds=%s, qb_rush_tds=%s, qb_YPA=%s"
            val = (teamID, oppID, week, teamName, oppName, qb_pass_att, qb_pass_comp, qb_pass_yds, qb_pass_tds, qb_rush_car, qb_rush_yds, qb_rush_tds, qb_YPA, teamID, oppID, week, teamName, oppName, qb_pass_att, qb_pass_comp, qb_pass_yds, qb_pass_tds, qb_rush_car, qb_rush_yds, qb_rush_tds, qb_YPA)
            mycursor = mydb.cursor()
            mycursor.execute(sql, val)
            mydb.commit()
            
            print (teamID, oppID, week, teamName, oppName, qb_pass_att, qb_pass_comp, qb_pass_yds, qb_pass_tds, qb_rush_car, qb_rush_yds, qb_rush_tds, qb_YPA)

def scrapeRBStats(week):
    # quarteback = qb; qb_rush_car, qb_rush_yds, qb_rush_tds, qb_pass_att, qb_pass_comp, qb_pass_yds, qb_pass_tds,
    # running back = rb; rb_rush_car, rb_rush_yds, rb_rush_tds, rb_rec_tar, rb_rec_comp rb_rec_yds, rb_rec_tds
    # wide reciever = wr; wr_rec_tar, wr_rec_comp, wr_rec_yds, wr_rec_tds
    # tight end = te; te_rec_tar, te_rec_comp, te_rec_wds, te_rec_tds
    
    # database connection
    mydb = connectToMySQL()

    # The url we will be scraping
    teamStats = "https://www.cbssports.com/fantasy/football/stats/posvsdef/RB/all/" + str(week) + "/standard" 
    # get the html
    html = urlopen(teamStats)
    # create the BeautifulSoup object
    soup = BeautifulSoup(html, "lxml")

    # collect team rows
    teamRows = soup.findAll(class_='data compact')[0].findAll('tr', {"class" : re.compile('row*')})

    week = str("%02d" % (week,))

    for team in teamRows:
        # check if total team stat row
        if not team.has_attr('id'):
            # team name 
            name = team.findAll('td')[1].getText()
            name = str(name.split()[0])
            teamID = getTeamID(name,True) + week
            teamName = getTeamName(str(getTeamID(name,True)))
            # opp name
            opp = team.findAll('td')[1].getText()
            opp = str(opp.split()[3])
            oppID = getTeamID(opp,True) + week
            oppName = getTeamName(str(getTeamID(opp,True)))
            # rb_rush_car, 2
            rb_rush_car = float(team.findAll('td')[2].getText())
            # rb_rush_yds, 3
            rb_rush_yds = float(team.findAll('td')[3].getText())
            # rb_rush_tds, 5
            rb_rush_tds = float(team.findAll('td')[5].getText())
            # rb_rec_tar, 6
            rb_rec_tar = float(team.findAll('td')[6].getText())
            # rb_rec_comp 7
            rb_rec_comp = float(team.findAll('td')[7].getText())
            # rb_rec_yds, 8
            rb_rec_yds = float(team.findAll('td')[8].getText())
            # rb_rec_tds 10
            rb_rec_tds = float(team.findAll('td')[10].getText())
            # rb_YPC
            if rb_rush_car == 0:
                rb_YPC = 0
            else:
                rb_YPC = round(rb_rush_yds/rb_rush_car,2)

            sql = "INSERT INTO teamStats(teamID, oppID, week, teamName, oppName, rb_rush_car, rb_rush_yds, rb_rush_tds, rb_rec_tar, rb_rec_comp, rb_rec_yds, rb_rec_tds, rb_YPC) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE teamID=%s, oppID=%s, week=%s, teamName=%s, oppName=%s, rb_rush_car=%s, rb_rush_yds=%s, rb_rush_tds=%s, rb_rec_tar=%s, rb_rec_comp=%s, rb_rec_yds=%s, rb_rec_tds=%s, rb_YPC=%s"
            val = (teamID, oppID, week, teamName, oppName, rb_rush_car, rb_rush_yds, rb_rush_tds, rb_rec_tar, rb_rec_comp, rb_rec_yds, rb_rec_tds, rb_YPC, teamID, oppID, week, teamName, oppName, rb_rush_car, rb_rush_yds, rb_rush_tds, rb_rec_tar, rb_rec_comp, rb_rec_yds, rb_rec_tds, rb_YPC)
            mycursor = mydb.cursor()
            mycursor.execute(sql, val)
            mydb.commit()
            
            print (teamID, oppID, week, teamName, oppName, rb_rush_car, rb_rush_yds, rb_rush_tds, rb_rec_tar, rb_rec_comp, rb_rec_yds, rb_rec_tds, rb_YPC)

def scrapeWRStats(week):
    # quarteback = qb; qb_rush_car, qb_rush_yds, qb_rush_tds, qb_pass_att, qb_pass_comp, qb_pass_yds, qb_pass_tds,
    # running back = rb; rb_rush_car, rb_rush_yds, rb_rush_tds, rb_rec_tar, rb_rec_comp rb_rec_yds, rb_rec_tds
    # wide reciever = wr; wr_rec_tar, wr_rec_comp, wr_rec_yds, wr_rec_tds
    # tight end = te; te_rec_tar, te_rec_comp, te_rec_wds, te_rec_tds
    
    # database connection
    mydb = connectToMySQL()

    # The url we will be scraping
    teamStats = "https://www.cbssports.com/fantasy/football/stats/posvsdef/WR/all/" + str(week) + "/standard" 
    # get the html
    html = urlopen(teamStats)
    # create the BeautifulSoup object
    soup = BeautifulSoup(html, "lxml")

    # collect team rows
    teamRows = soup.findAll(class_='data compact')[0].findAll('tr', {"class" : re.compile('row*')})

    week = str("%02d" % (week,))

    for team in teamRows:
        # check if total team stat row
        if not team.has_attr('id'):
            # team name 
            name = team.findAll('td')[1].getText()
            name = str(name.split()[0])
            teamID = getTeamID(name,True) + week
            teamName = getTeamName(str(getTeamID(name,True)))
            # opp name
            opp = team.findAll('td')[1].getText()
            opp = str(opp.split()[3])
            oppID = getTeamID(opp,True) + week
            oppName = getTeamName(str(getTeamID(opp,True)))
            # wr_rec_tar, 6 
            wr_rec_tar = float(team.findAll('td')[6].getText())
            # wr_rec_comp, 7
            wr_rec_comp = float(team.findAll('td')[7].getText())
            # wr_rec_yds, 8
            wr_rec_yds = float(team.findAll('td')[8].getText())
            # wr_rec_tds 10
            wr_rec_tds = float(team.findAll('td')[10].getText())
            # wr_YPT
            if wr_rec_tar == 0:
                wr_YPT = 0
            else:
                wr_YPT = round(wr_rec_yds/wr_rec_tar,2)

            sql = "INSERT INTO teamStats(teamID, oppID, week, teamName, oppName, wr_rec_tar, wr_rec_comp, wr_rec_yds, wr_rec_tds, wr_YPT) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE teamID=%s, oppID=%s, week=%s, teamName=%s, oppName=%s, wr_rec_tar=%s, wr_rec_comp=%s, wr_rec_yds=%s, wr_rec_tds=%s, wr_YPT=%s"
            val = (teamID, oppID, week, teamName, oppName, wr_rec_tar, wr_rec_comp, wr_rec_yds, wr_rec_tds, wr_YPT, teamID, oppID, week, teamName, oppName, wr_rec_tar, wr_rec_comp, wr_rec_yds, wr_rec_tds, wr_YPT)
            mycursor = mydb.cursor()
            mycursor.execute(sql, val)
            mydb.commit()
            
            print (teamID, oppID, week, teamName, oppName, wr_rec_tar, wr_rec_comp, wr_rec_yds, wr_rec_tds, wr_YPT)

def scrapeTEStats(week):
    # quarteback = qb; qb_rush_car, qb_rush_yds, qb_rush_tds, qb_pass_att, qb_pass_comp, qb_pass_yds, qb_pass_tds,
    # running back = rb; rb_rush_car, rb_rush_yds, rb_rush_tds, rb_rec_tar, rb_rec_comp rb_rec_yds, rb_rec_tds
    # wide reciever = wr; wr_rec_tar, wr_rec_comp, wr_rec_yds, wr_rec_tds
    # tight end = te; te_rec_tar, te_rec_comp, te_rec_wds, te_rec_tds
    
    # database connection
    mydb = connectToMySQL()

    # The url we will be scraping
    teamStats = "https://www.cbssports.com/fantasy/football/stats/posvsdef/TE/all/" + str(week) + "/standard" 
    # get the html
    html = urlopen(teamStats)
    # create the BeautifulSoup object
    soup = BeautifulSoup(html, "lxml")

    # collect team rows
    teamRows = soup.findAll(class_='data compact')[0].findAll('tr', {"class" : re.compile('row*')})

    week = str("%02d" % (week,))

    for team in teamRows:
        # check if total team stat row
        if not team.has_attr('id'):
            # team name 
            name = team.findAll('td')[1].getText()
            name = str(name.split()[0])
            teamID = getTeamID(name,True) + week
            teamName = getTeamName(str(getTeamID(name,True)))
            # opp name
            opp = team.findAll('td')[1].getText()
            opp = str(opp.split()[3])
            oppID = getTeamID(opp,True) + week
            oppName = getTeamName(str(getTeamID(opp,True)))
            # wr_rec_tar, 6 
            te_rec_tar = float(team.findAll('td')[6].getText())
            # wr_rec_comp, 7
            te_rec_comp = float(team.findAll('td')[7].getText())
            # wr_rec_yds, 8
            te_rec_yds = float(team.findAll('td')[8].getText())
            # wr_rec_tds 10
            te_rec_tds = float(team.findAll('td')[10].getText())
            # wr_YPT
            if te_rec_tar == 0:
                te_YPT = 0
            else:
                te_YPT = round(te_rec_yds/te_rec_tar,2)

            sql = "INSERT INTO teamStats(teamID, oppID, week, teamName, oppName, te_rec_tar, te_rec_comp, te_rec_yds, te_rec_tds, te_YPT) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE teamID=%s, oppID=%s, week=%s, teamName=%s, oppName=%s, te_rec_tar=%s, te_rec_comp=%s, te_rec_yds=%s, te_rec_tds=%s, te_YPT=%s"
            val = (teamID, oppID, week, teamName, oppName, te_rec_tar, te_rec_comp, te_rec_yds, te_rec_tds, te_YPT, teamID, oppID, week, teamName, oppName, te_rec_tar, te_rec_comp, te_rec_yds, te_rec_tds, te_YPT)
            mycursor = mydb.cursor()
            mycursor.execute(sql, val)
            mydb.commit()
            
            print (teamID, oppID, week, teamName, oppName, te_rec_tar, te_rec_comp, te_rec_yds, te_rec_tds, te_YPT)


def scrapeTotalStats(week):
    # quarteback = qb; qb_rush_car, qb_rush_yds, qb_rush_tds, qb_pass_att, qb_pass_comp, qb_pass_yds, qb_pass_tds,
    # running back = rb; rb_rush_car, rb_rush_yds, rb_rush_tds, rb_rec_tar, rb_rec_comp rb_rec_yds, rb_rec_tds
    # wide reciever = wr; wr_rec_tar, wr_rec_comp, wr_rec_yds, wr_rec_tds
    # tight end = te; te_rec_tar, te_rec_comp, te_rec_wds, te_rec_tds
    
    # database connection
    mydb = connectToMySQL()

    # The url we will be scraping
    teamStats = "https://www.cbssports.com/fantasy/football/stats/posvsdef/DST/all/" + str(week) + "/standard" 
    # get the html
    html = urlopen(teamStats)
    # create the BeautifulSoup object
    soup = BeautifulSoup(html, "lxml")

    # collect team rows
    teamRows = soup.findAll(class_='data compact')[0].findAll('tr', {"class" : re.compile('row*')})

    week = str("%02d" % (week,))

    for team in teamRows:
        # check if total team stat row
        if not team.has_attr('id'):
            # team name 
            name = team.findAll('td')[1].getText()
            name = str(name.split()[3])
            teamID = getTeamID(name,True) + week
            teamName = getTeamName(str(getTeamID(name,True)))
            # opp name
            opp = team.findAll('td')[1].getText()
            opp = str(opp.split()[0])
            oppID = getTeamID(opp,True) + week
            oppName = getTeamName(str(getTeamID(opp,True)))
            # total_rush_yds
            total_rush_yds = float(team.findAll('td')[11].getText())
            # total_pass_yds
            total_pass_yds = float(team.findAll('td')[10].getText())
            # total_scrim_yds
            total_scrim_yds = float(team.findAll('td')[12].getText())
            # total_points
            total_points = float(team.findAll('td')[9].getText())
            # sacks
            sacks = float(team.findAll('td')[4].getText())
            # ints
            ints = float(team.findAll('td')[2].getText())
            # fumrecs
            fumrecs = float(team.findAll('td')[6].getText())

            sql = "INSERT INTO teamStats(teamID, oppID, week, teamName, oppName, total_rush_yds, total_pass_yds, total_scrim_yds, total_points, sacks, ints, fumrecs) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE teamID=%s, oppID=%s, week=%s, teamName=%s, oppName=%s, total_rush_yds=%s, total_pass_yds=%s, total_scrim_yds=%s, total_points=%s, sacks=%s, ints=%s, fumrecs=%s"
            val = (teamID, oppID, week, teamName, oppName, total_rush_yds, total_pass_yds, total_scrim_yds, total_points, sacks, ints, fumrecs, teamID, oppID, week, teamName, oppName, total_rush_yds, total_pass_yds, total_scrim_yds, total_points, sacks, ints, fumrecs)
            mycursor = mydb.cursor()
            mycursor.execute(sql, val)
            mydb.commit()
            
            print (teamID, oppID, week, teamName, oppName, total_rush_yds, total_pass_yds, total_scrim_yds, total_points)


def scrapeAllStats(firstWeek,lastWeek):
    week = firstWeek
    while week <= lastWeek:
        scrapeQBStats(week)
        scrapeRBStats(week)
        scrapeWRStats(week)
        scrapeTEStats(week)
        scrapeTotalStats(week)
        week = week + 1

def calcAvgStat(stat):
     # database connection
    mydb = connectToMySQL()

    # team name array
    i = 0
    while i < len(teamNameLookup):
        # get all rows in dstStats
        sqlGet = "SELECT avg(" + str(stat) + ") FROM teamStats WHERE teamName = '" + str(teamNameLookup[i]) + "'"
        mycursor = mydb.cursor()
        mycursor.execute(sqlGet)
        avgStat = round(mycursor.fetchone()[0],2)
        print(str(teamNameLookup[i]),avgStat)

        teamName = str(teamNameLookup[i])
        teamID = str(getTeamID(teamName,False))

        sqlSet = "INSERT INTO teamStatsAvg(teamID, teamName, avg_" + str(stat) + ") VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE teamID=%s, teamName=%s, avg_" + str(stat) + "=%s"
        val = (teamID, teamName, avgStat, teamID, teamName, avgStat)
        mycursor.execute(sqlSet, val)
        mydb.commit()

        i = i + 1

def calcAvgAllowedStat(stat):
     # database connection
    mydb = connectToMySQL()

    # team name array
    i = 0
    while i < len(teamNameLookup):
        # get all rows in dstStats
        sqlGet = "SELECT avg(" + str(stat) + ") FROM teamStats WHERE oppName = '" + str(teamNameLookup[i]) + "'"
        mycursor = mydb.cursor()
        mycursor.execute(sqlGet)
        avgStat = round(mycursor.fetchone()[0],2)
        print(str(teamNameLookup[i]),avgStat)

        teamName = str(teamNameLookup[i])
        teamID = str(getTeamID(teamName,False))

        sqlSet = "INSERT INTO teamStatsAllowedAvg(teamID, teamName, avg_alwd_" + str(stat) + ") VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE teamID=%s, teamName=%s, avg_alwd_" + str(stat) + "=%s"
        val = (teamID, teamName, avgStat, teamID, teamName, avgStat)
        mycursor.execute(sqlSet, val)
        mydb.commit()

        i = i + 1

def calcAllAvgStats():
    # 5,36
    # database connection
    mydb = connectToMySQL()

    i = 5
    while i < 38:
        sqlGet = "DESCRIBE teamStats"
        mycursor = mydb.cursor()
        mycursor.execute(sqlGet)
        statName = mycursor.fetchall()[i][0]
        calcAvgStat(str(statName))
        i = i + 1

def calcAllAllowedAvgStats():
    # 5,36
    # database connection
    mydb = connectToMySQL()

    i = 5
    while i < 38:
        sqlGet = "DESCRIBE teamStats"
        mycursor = mydb.cursor()
        mycursor.execute(sqlGet)
        statName = mycursor.fetchall()[i][0]
        calcAvgAllowedStat(str(statName))
        i = i + 1

scrapeAllStats(13,13)
calcAllAvgStats()
calcAllAllowedAvgStats()