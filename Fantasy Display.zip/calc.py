from bs4 import BeautifulSoup
from urllib import urlopen
import math
import MySQLdb
import re
import statistics

teamShortNameLookup = ['Jets', 'Vikings', 'Ravens', 'Rams', 'Browns', 'Jaguars', 'Dolphins', 'Redskins', 'Panthers', 'Bears', 'Bengals', 'Broncos', 'Eagles', 'Lions', 'Steelers', 'Titans', 'Chiefs', 'Patriots', 'Buccaneers', 'Falcons', 'Cowboys', 'Texans', 'Seahawks', 'Packers', 'Giants', 'Cardinals', 'Colts', '49ers', 'Bills', 'Chargers', 'Raiders', 'Saints']
teamNameLookup = ['New York Jets', 'Minnesota Vikings', 'Baltimore Ravens', 'Los Angeles Rams', 'Cleveland Browns', 'Jacksonville Jaguars', 'Miami Dolphins', 'Washington Redskins', 'Carolina Panthers', 'Chicago Bears', 'Cincinnati Bengals', 'Denver Broncos', 'Philadelphia Eagles', 'Detroit Lions', 'Pittsburgh Steelers', 'Tennessee Titans', 'Kansas City Chiefs', 'New England Patriots', 'Tampa Bay Buccaneers', 'Atlanta Falcons', 'Dallas Cowboys', 'Houston Texans', 'Seattle Seahawks', 'Green Bay Packers', 'New York Giants', 'Arizona Cardinals', 'Indianapolis Colts', 'San Francisco 49ers', 'Buffalo Bills', 'Los Angeles Chargers', 'Oakland Raiders', 'New Orleans Saints']
teamIDLookup = ['NYJ', 'MIN', 'BAL', 'LA', 'CLE', 'JAX', 'MIA', 'WAS', 'CAR', 'CHI', 'CIN', 'DEN', 'PHI', 'DET', 'PIT', 'TEN', 'KC', 'NE', 'TB', 'ATL', 'DAL', 'HOU', 'SEA', 'GB', 'NYG', 'ARI', 'IND', 'SF', 'BUF', 'LAC', 'OAK', 'NO']

# return teamName function without DB
def getTeamName(teamID):
    teamIndex = teamIDLookup.index(teamID)
    return teamNameLookup[teamIndex]

# return teamID function without DB
def getTeamID(teamName,short):
    if short == True:
        teamIndex = teamShortNameLookup.index(teamName)
    else:
        teamIndex = teamNameLookup.index(teamName)
    
    return teamIDLookup[teamIndex]

# one function to sign into mysql
def connectToMySQL():
    mydb = MySQLdb.connect(
        host='localhost', #host='35.231.120.222', 
        user='root', 
        passwd='may132017',
        db='fantasyAnalytics'
    )
    return mydb

# get latest week
def getLatestWeek():
    mydb = connectToMySQL()

    sqlGet = "SELECT max(week) FROM teamStats"
    mycursor = mydb.cursor()
    mycursor.execute(sqlGet)
    week = mycursor.fetchone()[0]

    found = False

    while week>0 and found == False:
        # check that everyone has played
        sqlGet = "SELECT week"+str(week)+" FROM schedule"
        mycursor.execute(sqlGet)
        weekGames = [team[0] for team in mycursor.fetchall()]
        
        gameCount = 32
        for game in weekGames:
            if str(game) == 'BYE':
                gameCount = gameCount - 1
        
        # count the number of weeks in stats that match week
        sqlGet = " SELECT count("+str(week)+") FROM teamStats WHERE week = " + str(week)
        mycursor = mydb.cursor()
        mycursor.execute(sqlGet)
        statCount = mycursor.fetchone()[0]

        if gameCount == statCount:
            found == True
            return week
        else:
            week = week - 1

def calcDiff(teamID):    
     # database connection
    mydb = connectToMySQL()

    sqlGet = "SELECT avg(" + str(stat) + ") FROM teamStats WHERE teamName = '" + str(teamNameLookup[i]) + "'"
    mycursor = mydb.cursor()
    mycursor.execute(sqlGet)
    avgStat = round(mycursor.fetchone()[0],2)

def getSchedule(teamName, startWeek, endWeek):
    # database connection
    mydb = connectToMySQL()

    schedule = []
    i = startWeek

    while i <= endWeek:
        sqlGet = "SELECT week" + str(i) + " FROM schedule WHERE team = '" + teamName + "'"
        mycursor = mydb.cursor()
        mycursor.execute(sqlGet)
        schedule.append(mycursor.fetchone()[0])
        i = i + 1
    return schedule

def getOpp(teamName, week):
    # database connection
    mydb = connectToMySQL()
    # get opp
    sqlGet = "SELECT week" + str(week) + " FROM schedule WHERE team = '" + teamName + "'"
    mycursor = mydb.cursor()
    mycursor.execute(sqlGet)
    return mycursor.fetchone()[0]

def getStat(teamName,week,statName):
    # database connection
    mydb = connectToMySQL()

    sqlGet = "SELECT " + statName + " FROM teamStats WHERE teamName = '" + teamName + "' AND week = " + str(week)
    mycursor = mydb.cursor()
    mycursor.execute(sqlGet)
    stat = mycursor.fetchone()[0]
    return stat

def getStatAvg(teamName,statName):
    # database connection
    mydb = connectToMySQL()

    sqlGet = "SELECT avg_" + statName + " FROM teamStatsAvg WHERE teamName = '" + teamName + "'"
    mycursor = mydb.cursor()
    mycursor.execute(sqlGet)
    avgStat = mycursor.fetchone()[0]
    return avgStat

def getStatAllowedAvg(teamName,statName):
    # database connection
    mydb = connectToMySQL()

    sqlGet = "SELECT avg_alwd_" + statName + " FROM teamStatsAllowedAvg WHERE teamName = '" + teamName + "'"
    mycursor = mydb.cursor()
    mycursor.execute(sqlGet)
    avgStat = mycursor.fetchone()[0]
    return avgStat

def getStatRanking(teamName,statName):
    # database connection
    mydb = connectToMySQL()

    sqlGet = "SELECT teamName FROM teamStatsAvg ORDER BY avg_"+statName
    mycursor = mydb.cursor()
    mycursor.execute(sqlGet)
    rankArray = [team[0] for team in mycursor.fetchall()]
    rank = rankArray.index(str(teamName))
    return rank + 1

def getStatAllowedRanking(teamName,statName):
    # database connection
    mydb = connectToMySQL()

    sqlGet = "SELECT teamName FROM teamStatsAllowedAvg ORDER BY avg_alwd_"+statName
    mycursor = mydb.cursor()
    mycursor.execute(sqlGet)
    rankArray = [team[0] for team in mycursor.fetchall()]
    rank = rankArray.index(str(teamName))
    return rank + 1

def getStatTakenDiff(teamName,statName):
    latestWeek = getLatestWeek()
    # get all opps
    oppIDs = getSchedule(teamName,1,latestWeek)
    # loop through all opps
    week = 1
    gamesPlayed = 0
    weightedDiffSum = 0
    diffSum = 0
    for oppID in oppIDs:
        if oppID != 'BYE':
            # get opp
            oppName = getTeamName(oppID)

            gameStat = getStat(teamName,week,statName)
            oppAvgAlwdStat = getStatAllowedAvg(oppName,statName)
            gameStatDiff = gameStat - oppAvgAlwdStat

            # get statAllowedRanking for weighting
            rank = getStatAllowedRanking(oppName,statName)
            # tier calc
            tier = math.floor(rank/8)
            if diffSum > 0:
                weight = -0.25*tier+1.75
            else:
                weight = 0.25*tier+1

            weightedDiffSum = weightedDiffSum + gameStatDiff*weight
            diffSum = diffSum + gameStatDiff

            week = week + 1
            gamesPlayed = gamesPlayed + 1
        else:
            week = week + 1
    return round(weightedDiffSum/gamesPlayed,2)

def getStatAllowedDiff(teamName,statName):
    latestWeek = getLatestWeek()
    # get all opps
    oppIDs = getSchedule(teamName,1,latestWeek)
    # loop through all opps
    week = 1
    gamesPlayed = 0
    weightedDiffSum = 0
    diffSum = 0
    for oppID in oppIDs:
        if oppID != 'BYE':
            # get opp
            oppName = getTeamName(oppID)

            gameStat = getStat(oppName,week,statName)
            oppAvgStat = getStatAvg(oppName,statName)
            gameStatDiff = gameStat - oppAvgStat

            # get statAllowedRanking for weighting
            rank = getStatRanking(oppName,statName)
            # tier calc
            tier = math.floor(rank/8)
            if diffSum > 0:
                weight = -0.25*tier+1.75
            else:
                weight = 0.25*tier+1

            weightedDiffSum = weightedDiffSum + gameStatDiff*weight
            diffSum = diffSum + gameStatDiff

            week = week + 1
            gamesPlayed = gamesPlayed + 1
        else:
            week = week + 1
    return round(weightedDiffSum/gamesPlayed,2)

def getConsistencyFactor(teamName,statName,allowed):
    # get teamID
    teamID = getTeamID(teamName,False)
    if allowed != True:
        caseID = 'teamID'
    else:
        caseID = 'oppID'

    # database connection
    mydb = connectToMySQL()

    sqlGet = "SELECT "+statName+" FROM teamStats WHERE "+caseID+" LIKE '"+teamID+"%'"
    mycursor = mydb.cursor()
    mycursor.execute(sqlGet)
    statArray = [float(stat[0]) for stat in mycursor.fetchall()]
    return statistics.stdev(statArray)

def getTakenProjection(teamName,oppName,statName):
    teamAvgStatTaken = getStatAvg(teamName,statName)
    oppAvgStatAllowed = getStatAllowedAvg(teamName,statName)
    teamStatTakenDiff = getStatTakenDiff(teamName,statName)
    oppStatAllowedDiff = getStatAllowedDiff(oppName,statName)

    # consistancy factors
    teamSD = getConsistencyFactor(teamName,statName,False)
    oppSD = getConsistencyFactor(oppName,statName,True)

    if teamSD == 0 or oppSD == 0:
        teamCF = 0.5
        oppCF = 0.5
    else:
        teamCF = oppSD/(teamSD+oppSD)
        oppCF = teamSD/(teamSD+oppSD)

    proj = (teamAvgStatTaken + oppStatAllowedDiff)*teamCF + (oppAvgStatAllowed + teamStatTakenDiff)*oppCF
    
    #print(teamName + ": allow on avg " + str(teamAvgStatAllowed) + " with an SD of " + str(teamSD) + " " + str(teamCF))
    #print(oppName + ": take on avg " + str(oppAvgStatTaken) + " with an SD of " + str(oppSD) + " " + str(oppCF))
    #print("weighted team prevention: " + str(teamStatAllowedDiff))
    #print("weighted opp taking: " + str(oppStatTakenDiff))
    return proj

def getAllowedProjection(teamName,oppName,statName):
    teamAvgStatAllowed = getStatAllowedAvg(teamName,statName)
    oppAvgStatTaken = getStatAvg(teamName,statName)
    teamStatAllowedDiff = getStatAllowedDiff(teamName,statName)
    oppStatTakenDiff = getStatTakenDiff(oppName,statName)

    # consistancy factors
    teamSD = getConsistencyFactor(teamName,statName,True)
    oppSD = getConsistencyFactor(oppName,statName,False)

    if teamSD == 0 or oppSD == 0:
        teamCF = 0.5
        oppCF = 0.5
    else:
        teamCF = oppSD/(teamSD+oppSD)
        oppCF = teamSD/(teamSD+oppSD)

    proj = (teamAvgStatAllowed + oppStatTakenDiff)*teamCF + (oppAvgStatTaken + teamStatAllowedDiff)*oppCF
    
    #print(teamName + ": allow on avg " + str(teamAvgStatAllowed) + " with an SD of " + str(teamSD) + " " + str(teamCF))
    #print(oppName + ": take on avg " + str(oppAvgStatTaken) + " with an SD of " + str(oppSD) + " " + str(oppCF))
    #print("weighted team prevention: " + str(teamStatAllowedDiff))
    #print("weighted opp taking: " + str(oppStatTakenDiff))
    return proj

def getQBFantasyPoints(passYds,passTDs,rushYds,rushTDs,ints):
    return (passYds/25) + (passTDs*4) + (rushYds/10) + rushTDs*6 - (ints*2)
def getRBFantasyPoints(rushYds,rushTDs,recYds,recTDs):
    return (rushYds/10) + (rushTDs*6) + (recYds/10) + recTDs*6
def getWRTEFantasyPoints(recYds,recTDs):
    return (recYds/10) + (recTDs*6)

def getDSTFantasyPoints(sacks, inters, fumRecs, safties, blocks, tds, ptsAllowed, totYards):
    stats = [sacks, inters, fumRecs, safties, blocks, tds, ptsAllowed, totYards]
    # calc tier for ptsAllowed
    pointsPA = 0
    if stats[6] == 0: pointsPA = 5
    elif 1 <= stats[6] <= 6: pointsPA = 4
    elif 7 <= stats[6] <= 13: pointsPA = 3
    elif 14 <= stats[6] <= 17: pointsPA = 1
    elif 18 <= stats[6] <= 27: pointsPA = 0
    elif 28 <= stats[6] <= 34: pointsPA = -1
    elif 35 <= stats[6] <= 45: pointsPA = -3
    elif 46 <= stats[6]: pointsPA = -5
    # calc tier for ydsAllowed
    pointsYA = 0
    if stats[7] < 100: pointsYA = 5
    elif 100 <= stats[7] <= 199: pointsYA = 3
    elif 200 <= stats[7] <= 299: pointsYA = 2
    elif 300 <= stats[7] <= 399: pointsYA = -1
    elif 400 <= stats[7] <= 449: pointsYA = -3
    elif 450 <= stats[7] <= 499: pointsYA = -5
    elif 500 <= stats[7] <= 549: pointsYA = -6
    elif 550 <= stats[7]: pointsYA = -7

    # calculate the points
    fantasyPoints = stats[0]*1 + stats[1]*2 + stats[2]*2 + stats[3]*2 + stats[4]*2 + stats[5]*6 + pointsPA + pointsYA
    return fantasyPoints

def getDSTProjection(teamName,week):
    # get opp
    oppID = getOpp(teamName,week)

    # check for BYE
    if oppID != 'BYE':

        oppName = getTeamName(oppID)

        ptsAllowed = getAllowedProjection(teamName,oppName,'total_points')
        rushYdsAllowed = getAllowedProjection(teamName,oppName,'total_rush_yds')
        passYdsAllowed = getAllowedProjection(teamName,oppName,'total_pass_yds')
        totalYdsAllowed = float(rushYdsAllowed) + float(passYdsAllowed)
        sacksTaken = getTakenProjection(teamName,oppName,'sacks')
        intsTaken = getTakenProjection(teamName,oppName,'ints')
        fumRecsTaken = getTakenProjection(teamName,oppName,'fumrecs')

        return getDSTFantasyPoints(sacksTaken, intsTaken, fumRecsTaken, 0, 0, 0, ptsAllowed, totalYdsAllowed)
    else:
        print teamName + ' BYE'

def getQBProjection(teamName,week):
    # get opp
    oppID = getOpp(teamName,week)

    # check for BYE
    if oppID != 'BYE':

        oppName = getTeamName(oppID)

        proj_qb_rush_car = getTakenProjection(teamName,oppName,'qb_rush_car')
        proj_qb_rush_yds = getTakenProjection(teamName,oppName,'qb_rush_yds')
        proj_qb_rush_tds = getTakenProjection(teamName,oppName,'qb_rush_tds')
        proj_qb_pass_att = getTakenProjection(teamName,oppName,'qb_pass_att')
        proj_qb_pass_comp = getTakenProjection(teamName,oppName,'qb_pass_comp')
        proj_qb_pass_yds = getTakenProjection(teamName,oppName,'qb_pass_yds')
        proj_qb_pass_tds = getTakenProjection(teamName,oppName,'qb_pass_tds')
        proj_qb_YPA = getTakenProjection(teamName,oppName,'qb_YPA')
        proj_ints = getTakenProjection(teamName,oppName,'ints')

        qbProj = getQBFantasyPoints(proj_qb_YPA*proj_qb_pass_att,proj_qb_pass_tds,proj_qb_rush_yds,proj_qb_rush_tds,proj_ints)
        
        return qbProj
    else:
        print teamName + ' BYE'

def getRBProjection(teamName,week):
    # get opp
    oppID = getOpp(teamName,week)

    # check for BYE
    if oppID != 'BYE':

        oppName = getTeamName(oppID)

        proj_rb_rush_car = getTakenProjection(teamName,oppName,'rb_rush_car')
        proj_rb_rush_yds = getTakenProjection(teamName,oppName,'rb_rush_yds')
        proj_rb_rush_tds = getTakenProjection(teamName,oppName,'rb_rush_tds')
        proj_rb_rec_tar = getTakenProjection(teamName,oppName,'rb_rec_tar')
        proj_rb_rec_comp = getTakenProjection(teamName,oppName,'rb_rec_comp')
        proj_rb_rec_yds = getTakenProjection(teamName,oppName,'rb_rec_yds')
        proj_rb_rec_tds = getTakenProjection(teamName,oppName,'rb_rec_tds')
        proj_rb_YPC = getTakenProjection(teamName,oppName,'rb_YPC')
        
        rbProj = getRBFantasyPoints(proj_rb_YPC*proj_rb_rush_car,proj_rb_rush_tds,proj_rb_rec_yds,proj_rb_rec_tds)
        
        return rbProj
    else:
        print teamName + ' BYE'

def getWRProjection(teamName,week):
    # get opp
    oppID = getOpp(teamName,week)

    # check for BYE
    if oppID != 'BYE':

        oppName = getTeamName(oppID)

        proj_wr_rec_tar = getTakenProjection(teamName,oppName,'wr_rec_tar')
        proj_wr_rec_comp = getTakenProjection(teamName,oppName,'wr_rec_comp')
        proj_wr_rec_yds = getTakenProjection(teamName,oppName,'wr_rec_yds')
        proj_wr_rec_tds = getTakenProjection(teamName,oppName,'wr_rec_tds')
        proj_wr_YPT = getTakenProjection(teamName,oppName,'wr_YPT')

        wrProj = getWRTEFantasyPoints(proj_wr_YPT*proj_wr_rec_tar,proj_wr_rec_tds)
        
        return wrProj
    else:
        print teamName + ' BYE'

def getTEProjection(teamName,week):
    # get opp
    oppID = getOpp(teamName,week)

    # check for BYE
    if oppID != 'BYE':

        oppName = getTeamName(oppID)

        proj_te_rec_tar = getTakenProjection(teamName,oppName,'te_rec_tar')
        proj_te_rec_comp = getTakenProjection(teamName,oppName,'te_rec_comp')
        proj_te_rec_yds = getTakenProjection(teamName,oppName,'te_rec_yds')
        proj_te_rec_tds = getTakenProjection(teamName,oppName,'te_rec_tds')
        proj_te_YPT = getTakenProjection(teamName,oppName,'te_YPT')

        teProj = getWRTEFantasyPoints(proj_te_YPT*proj_te_rec_tar,proj_te_rec_tds)
        
        return teProj
    else:
        print teamName + ' BYE'
    
def storeAllDSTProjections(week):
     # database connection
    mydb = connectToMySQL()

    for teamName in teamNameLookup:
        proj = getDSTProjection(teamName,week)

        sql = "INSERT INTO dstProjections (teamID, team, week" + str(week) + ") VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE week" + str(week) +"=%s"
        val =  (getTeamID(teamName,False), teamName, proj, proj)
        mycursor = mydb.cursor()
        mycursor.execute(sql, val)
        mydb.commit()

def storeAllQBProjections(week):
     # database connection
    mydb = connectToMySQL()

    for teamName in teamNameLookup:
        proj = getQBProjection(teamName,week)
        print teamName,proj

        sql = "INSERT INTO qbProjections (teamID, team, week" + str(week) + ") VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE week" + str(week) +"=%s"
        val =  (getTeamID(teamName,False), teamName, proj, proj)
        mycursor = mydb.cursor()
        mycursor.execute(sql, val)
        mydb.commit()

def storeAllRBProjections(week):
     # database connection
    mydb = connectToMySQL()

    for teamName in teamNameLookup:
        proj = getRBProjection(teamName,week)
        print teamName,proj

        sql = "INSERT INTO rbProjections (teamID, team, week" + str(week) + ") VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE week" + str(week) +"=%s"
        val =  (getTeamID(teamName,False), teamName, proj, proj)
        mycursor = mydb.cursor()
        mycursor.execute(sql, val)
        mydb.commit()

def storeAllWRProjections(week):
     # database connection
    mydb = connectToMySQL()

    for teamName in teamNameLookup:
        proj = getWRProjection(teamName,week)
        print teamName,proj

        sql = "INSERT INTO wrProjections (teamID, team, week" + str(week) + ") VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE week" + str(week) +"=%s"
        val =  (getTeamID(teamName,False), teamName, proj, proj)
        mycursor = mydb.cursor()
        mycursor.execute(sql, val)
        mydb.commit()

def storeAllTEProjections(week):
     # database connection
    mydb = connectToMySQL()

    for teamName in teamNameLookup:
        proj = getTEProjection(teamName,week)
        print teamName,proj

        sql = "INSERT INTO teProjections (teamID, team, week" + str(week) + ") VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE week" + str(week) +"=%s"
        val =  (getTeamID(teamName,False), teamName, proj, proj)
        mycursor = mydb.cursor()
        mycursor.execute(sql, val)
        mydb.commit()

def storeAllProjections(week):
    storeAllQBProjections(week)
    storeAllRBProjections(week)
    storeAllWRProjections(week)
    storeAllTEProjections(week)
    storeAllDSTProjections(week)

storeAllProjections(12)
storeAllProjections(13)
storeAllProjections(14)
storeAllProjections(15)
storeAllProjections(16)
